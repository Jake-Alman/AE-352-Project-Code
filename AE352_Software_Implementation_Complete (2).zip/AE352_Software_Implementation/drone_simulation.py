"""AE352 quadrotor six-DOF digital twin. SI units throughout.

Run: python drone_simulation.py
Dependencies: numpy, scipy, matplotlib

Rotor order: +X, +Y, -X, -Y. Positive Z is up. Body X forward.
Team specifications: 2 kg (ballasted), 500 mm frame, four 920 KV motors,
10-inch props, 4S 5000 mAh LiPo, Pixhawk and optical flow sensor.
Unverified aerodynamic and actuator parameters remain illustrative.
"""
from __future__ import annotations
import csv
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.spatial.transform import Rotation
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
FIGURES = ROOT / 'figures'
FIGURES.mkdir(exist_ok=True)

@dataclass(frozen=True)
class Parameters:
    mass: float = 2.00           # kg, includes added ballast (team target)
    arm: float = 0.25            # m, assuming 500 mm is diagonal motor-to-motor span
    Ixx: float = 0.035           # kg m^2 (estimated, requires CAD/mass verification)
    Iyy: float = 0.035
    Izz: float = 0.065
    thrust_coeff: float = 1.4e-5 # N/(rad/s)^2
    drag_torque_coeff: float = 2.5e-7 # N m/(rad/s)^2
    rotor_inertia: float = 1.0e-5 # kg m^2
    motor_time_constant: float = 0.055 # s (speed closed-loop response)
    max_motor_torque: float = 0.26  # N m (positive or braking)
    max_rotor_speed: float = 850.0  # rad/s assumed loaded limit; below 920 KV x 14.8 V no-load speed
    rotor_power_coeff: float = 1.8e-7 # W/(rad/s)^3 (illustrative)
    electronics_power: float = 8.0  # W
    battery_Wh: float = 74.0     # Wh, nominal 4S (14.8 V) x 5 Ah; provided team battery
    usable_fraction: float = 0.80 # fraction of nominal usable
    gravity: float = 9.81
    kp_pos: float = 1.3          # 1/s^2
    kd_pos: float = 2.4          # 1/s
    kp_att: float = 0.50         # N m/rad
    kd_att: float = 0.28         # N m s/rad

P = Parameters()
SPIN = np.array([1., -1., 1., -1.])


def quat_to_rotation(q):
    # quaternion state uses [qw, qx, qy, qz]
    return Rotation.from_quat([q[1], q[2], q[3], q[0]]).as_matrix()


def quat_derivative(q, w):
    qw, qx, qy, qz = q
    wx, wy, wz = w
    return 0.5 * np.array([
        -qx*wx-qy*wy-qz*wz,
        qw*wx+qy*wz-qz*wy,
        qw*wy+qz*wx-qx*wz,
        qw*wz+qx*wy-qy*wx
    ])


def minimum_jerk(t, t0, duration, start, finish):
    """Returns smooth position, velocity, acceleration for a scalar transition."""
    u = np.clip((t - t0) / duration, 0., 1.)
    s = 10*u**3-15*u**4+6*u**5
    sd = (30*u**2-60*u**3+30*u**4)/duration
    sdd = (60*u-180*u**2+120*u**3)/duration**2
    if t <= t0 or t >= t0+duration:
        sd, sdd = 0., 0.
    d = finish-start
    return start+d*s, d*sd, d*sdd


def reference(scenario, t):
    """Returns desired position, velocity, acceleration, yaw, and yaw rate."""
    p = np.zeros(3)
    v = np.zeros(3)
    a = np.zeros(3)
    yaw, yaw_rate = 0., 0.
    if scenario == 'hover':
        # 5 s takeoff, then 120 s steady hover
        p[2], v[2], a[2] = minimum_jerk(t, 0., 5., 0., 1.)
    elif scenario == 'circle':
        # Start already at 1 m and at (2,0); circle continuously for 65 s.
        w = 0.5/2.0
        p[:] = [2*np.cos(w*t), 2*np.sin(w*t), 1.]
        v[:] = [-2*w*np.sin(w*t), 2*w*np.cos(w*t), 0.]
        a[:] = [-2*w*w*np.cos(w*t), -2*w*w*np.sin(w*t), 0.]
    elif scenario == 'mission':
        # 0-5 takeoff; 7-12 +X 5 m; 14-18 hover + yaw left;
        # 20-25 +Y 5 m; 27-147 descent at <= 0.01 m/s (ideal reference).
        p[2], v[2], a[2] = minimum_jerk(t, 0., 5., 0., 1.)
        if t >= 27.:
            p[2], v[2], a[2] = minimum_jerk(t, 27., 120., 1., 0.)
        p[0], v[0], a[0] = minimum_jerk(t, 7., 5., 0., 5.)
        p[1], v[1], a[1] = minimum_jerk(t, 20., 5., 0., 5.)
        yaw, yaw_rate, _ = minimum_jerk(t, 14., 4., 0., np.pi/2)
    else:
        raise ValueError(f'Unknown scenario: {scenario}')
    return p, v, a, yaw, yaw_rate


def mixer_matrix(par):
    k, L, b = par.thrust_coeff, par.arm, par.drag_torque_coeff
    # generalized force = [total body z thrust, roll, pitch, yaw]
    return np.array([
        [k, k, k, k],
        [0., L*k, 0., -L*k],
        [-L*k, 0., L*k, 0.],
        -SPIN*b,
    ])


def calculate_controls(scenario, t, state, par=P):
    pos, vel, q, w, omega = state[:3], state[3:6], state[6:10], state[10:13], state[13:17]
    R = quat_to_rotation(q)
    pd, vd, ad, yaw, yaw_rate = reference(scenario, t)
    desired_force = par.mass * (ad + par.kp_pos*(pd-pos) + par.kd_pos*(vd-vel) + np.array([0.,0.,par.gravity]))
    # desired body Z-axis follows the requested world-frame thrust direction
    b3 = desired_force / np.linalg.norm(desired_force)
    heading = np.array([np.cos(yaw), np.sin(yaw), 0.])
    b2 = np.cross(b3, heading)
    b2 /= np.linalg.norm(b2)
    b1 = np.cross(b2, b3)
    Rd = np.column_stack([b1, b2, b3])
    E = Rd.T @ R - R.T @ Rd
    eR = 0.5 * np.array([E[2,1], E[0,2], E[1,0]])
    desired_body_rates = R.T @ np.array([0., 0., yaw_rate])
    I = np.diag([par.Ixx, par.Iyy, par.Izz])
    M = -par.kp_att*eR - par.kd_att*(w-desired_body_rates) + np.cross(w, I@w)
    # Physical collective force is F dotted with current body Z (never negative).
    thrust = max(0., desired_force @ R[:,2])
    generalized = np.array([thrust, *M])
    rotor_speed_sq = np.linalg.solve(mixer_matrix(par), generalized)
    # Clip commands to physical rotor-speed limits. Retains true coupled actuator effects.
    requested_rotor_speed = np.sqrt(np.clip(rotor_speed_sq, 0., par.max_rotor_speed**2))
    # Motor torque controls rotor angular acceleration; equilibrium torque balances prop drag.
    requested_torque = (par.drag_torque_coeff*omega**2
                        + par.rotor_inertia*(requested_rotor_speed-omega)/par.motor_time_constant)
    torque = np.clip(requested_torque, -par.max_motor_torque, par.max_motor_torque)
    return torque, requested_rotor_speed, np.array([pd, vd, ad]), generalized


def rhs(t, state, scenario, par=P):
    pos, vel, q, w, omega = state[:3], state[3:6], state[6:10], state[10:13], state[13:17]
    R = quat_to_rotation(q)
    tau, _, _, _ = calculate_controls(scenario, t, state, par)
    rotor_accel = (tau-par.drag_torque_coeff*omega**2)/par.rotor_inertia
    rotor_accel = np.where((omega <= 0.) & (rotor_accel < 0.), 0., rotor_accel)
    rotor_accel = np.where((omega >= par.max_rotor_speed) & (rotor_accel > 0.), 0., rotor_accel)
    thrusts = par.thrust_coeff * omega**2
    net_thrust = np.sum(thrusts)
    accel = R @ np.array([0.,0.,net_thrust])/par.mass-np.array([0.,0.,par.gravity])
    # Torque from thrust offset and reaction torques due to accelerating motors.
    # Rotor spin also generates body gyroscopic moment, neglected in this baseline model.
    moments = np.array([
        par.arm*(thrusts[1]-thrusts[3]),
        par.arm*(thrusts[2]-thrusts[0]),
        -np.dot(SPIN, tau)
    ])
    I = np.diag([par.Ixx, par.Iyy, par.Izz])
    wdot = np.linalg.solve(I, moments - np.cross(w, I@w))
    power_W = par.rotor_power_coeff*np.sum(omega**3)+par.electronics_power
    return np.concatenate([vel, accel, quat_derivative(q,w), wdot, rotor_accel, [power_W/3600.]])


def initial_state(scenario, par=P):
    s = np.zeros(18)
    s[6] = 1.  # quaternion identity
    omega_hover = np.sqrt(par.mass*par.gravity/(4*par.thrust_coeff))
    s[13:17] = omega_hover
    if scenario == 'circle':
        pd, vd, _, _, _ = reference('circle', 0.)
        s[:3] = pd
        s[3:6] = vd
    return s


def simulate(scenario, dt=0.1, par=P):
    end = {'hover': 125., 'circle': 65., 'mission': 152.}[scenario]
    times = np.arange(0., end+0.5*dt, dt)
    sol = solve_ivp(rhs, (0., end), initial_state(scenario,par), args=(scenario,par),
                    method='RK45', t_eval=times, max_step=0.05, rtol=2e-6, atol=1e-8)
    if not sol.success:
        raise RuntimeError(sol.message)
    state = sol.y.T
    ref = np.array([reference(scenario,t)[0] for t in times])
    angles = np.array([Rotation.from_matrix(quat_to_rotation(q)).as_euler('xyz',degrees=True)
                       for q in state[:,6:10]])
    torque = np.array([calculate_controls(scenario,t,s,par)[0] for t,s in zip(times,state)])
    powers = par.rotor_power_coeff*np.sum(state[:,13:17]**3,axis=1)+par.electronics_power
    result = dict(t=times, s=state, ref=ref, euler=angles, motor_torque=torque, power=powers)
    return result


def stats(scenario, result, par=P):
    t, s, ref = result['t'], result['s'], result['ref']
    err = np.linalg.norm(s[:,:3]-ref,axis=1)
    energy_Wh = s[-1,17]
    usable = par.battery_Wh*par.usable_fraction
    out = {'scenario':scenario,'duration_s':round(float(t[-1]),3),
           'total_energy_Wh':round(float(energy_Wh),3),
           'battery_usable_Wh':round(usable,3),
           'battery_remaining_Wh':round(usable-energy_Wh,3),
           'max_position_error_m':round(float(err.max()),4),
           'rms_position_error_m':round(float(np.sqrt(np.mean(err**2))),4),
           'max_motor_speed_rad_s':round(float(s[:,13:17].max()),2),
           'max_motor_torque_Nm':round(float(np.abs(result['motor_torque']).max()),4)}
    if scenario=='hover':
        segment = (t>=5.) & (t<=125.)
        out['hover_duration_s'] = 120.
        out['hover_mean_altitude_m'] = round(float(s[segment,2].mean()),4)
        out['hover_max_altitude_error_m'] = round(float(np.max(np.abs(s[segment,2]-1.))),4)
    if scenario=='circle':
        segment=(t>=0.) & (t<=60.)
        radius = np.linalg.norm(s[segment,:2],axis=1)
        planar_speed = np.linalg.norm(s[segment,3:5],axis=1)
        out['circle_duration_s']=60.
        out['circle_mean_radius_m']=round(float(radius.mean()),4)
        out['circle_mean_speed_m_s']=round(float(planar_speed.mean()),4)
        out['circle_mean_altitude_m']=round(float(s[segment,2].mean()),4)
        out['circle_radius_max_error_m']=round(float(np.max(abs(radius-2.))),4)
    if scenario=='mission':
        out['first_leg_endpoint_error_m'] = round(float(np.linalg.norm(s[np.argmin(abs(t-14.)),:2]-np.array([5.,0.]))),4)
        out['second_leg_endpoint_error_m'] = round(float(np.linalg.norm(s[np.argmin(abs(t-27.)),:2]-np.array([5.,5.]))),4)
        yaw_final = float(result['euler'][-1,2])
        out['final_yaw_deg']=round(yaw_final,3)
        out['final_altitude_m']=round(float(s[-1,2]),5)
        out['final_vertical_speed_m_s']=round(float(s[-1,5]),5)
        out['max_descent_speed_final_2s_m_s']=round(float(max(0.,-np.min(s[t>=145.,5]))),5)
    return out


def save_plots(scenario,result):
    t, s, ref = result['t'], result['s'], result['ref']
    fig,axs=plt.subplots(3,1,figsize=(10,9),sharex=True)
    for j,k in enumerate('xyz'):
        axs[j].plot(t,s[:,j],label=f'{k} actual')
        axs[j].plot(t,ref[:,j],'--',label=f'{k} reference',alpha=.8)
        axs[j].set_ylabel(f'{k} (m)'); axs[j].grid(alpha=.3);axs[j].legend(loc='best')
    axs[-1].set_xlabel('Time (s)'); fig.suptitle(scenario.title()+': center-of-mass position')
    fig.tight_layout();fig.savefig(FIGURES/f'{scenario}_position.png',dpi=150);plt.close(fig)
    fig,axs=plt.subplots(3,1,figsize=(10,8),sharex=True)
    for j,k in enumerate(['Roll','Pitch','Yaw']):
        axs[j].plot(t,result['euler'][:,j]);axs[j].set_ylabel(k+' (deg)');axs[j].grid(alpha=.3)
    axs[-1].set_xlabel('Time (s)');fig.suptitle(scenario.title()+': Euler angles')
    fig.tight_layout();fig.savefig(FIGURES/f'{scenario}_attitude.png',dpi=150);plt.close(fig)
    fig,axs=plt.subplots(2,1,figsize=(10,7),sharex=True)
    for i in range(4):
        axs[0].plot(t,s[:,13+i],label=f'Rotor {i+1}')
        axs[1].plot(t,result['motor_torque'][:,i],label=f'Motor {i+1}')
    axs[0].set_ylabel('Rotor speed (rad/s)');axs[0].legend(ncol=4,fontsize=8)
    axs[1].set_ylabel('Motor torque (N m)');axs[1].set_xlabel('Time (s)')
    for ax in axs:ax.grid(alpha=.3)
    fig.suptitle(scenario.title()+': individual actuators')
    fig.tight_layout();fig.savefig(FIGURES/f'{scenario}_motors.png',dpi=150);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,6))
    ax.plot(s[:,0],s[:,1],label='Simulated')
    ax.plot(ref[:,0],ref[:,1],'--',label='Reference')
    ax.scatter([s[0,0]],[s[0,1]],marker='o',label='Start')
    ax.set_aspect('equal',adjustable='datalim');ax.set_xlabel('x (m)');ax.set_ylabel('y (m)')
    ax.grid(alpha=.3);ax.legend();ax.set_title(scenario.title()+': top-down trajectory')
    fig.tight_layout();fig.savefig(FIGURES/f'{scenario}_path.png',dpi=150);plt.close(fig)


def main():
    import json
    report={}
    for name in ('hover','circle','mission'):
        print('Running:',name,flush=True)
        r=simulate(name)
        save_plots(name,r)
        report[name]=stats(name,r)
        with (ROOT/f'{name}_timeseries.csv').open('w',newline='') as fh:
            writer=csv.writer(fh)
            writer.writerow(['time_s','x_m','y_m','z_m','vx_m_s','vy_m_s','vz_m_s',
                             'roll_deg','pitch_deg','yaw_deg', 'omega1_rad_s','omega2_rad_s',
                             'omega3_rad_s','omega4_rad_s','power_W','energy_Wh'])
            for i,t in enumerate(r['t']):
                writer.writerow([t,*r['s'][i,:6],*r['euler'][i],*r['s'][i,13:17],r['power'][i],r['s'][i,17]])
        print(json.dumps(report[name],indent=2),flush=True)
    with (ROOT/'simulation_results.json').open('w') as fh:
        json.dump(report,fh,indent=2)
    print('Wrote figures, CSV files, and simulation_results.json to',ROOT)

if __name__=='__main__':
    main()
