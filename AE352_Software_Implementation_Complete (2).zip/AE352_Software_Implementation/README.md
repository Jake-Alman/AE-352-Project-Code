# AE352 Quadrotor Digital Twin — 2 kg team specification

## Run

Install Python 3.10+ and `pip install numpy scipy matplotlib`, then run:

```bash
python drone_simulation.py
python test_simulation.py
```

These commands write figures, three time-series CSVs, and `simulation_results.json`.

## Provided team hardware specifications

- 500 mm carbon fiber quadcopter frame (opposite-motor span **assumed**, not checked against frame SKU)
- Four 920 KV brushless motors and 10-inch propellers
- 4S 5000 mAh LiPo (74 Wh nominal at 14.8 V; assumes 80% usable = 59.2 Wh)
- Pixhawk flight controller and optical-flow sensor (hardware concept only; ideal feedback used)
- Assembly before ballast 1.7 kg; 0.3 kg ballast added; total modeled mass **2.0 kg**

## Assumptions that must be verified

The 500 mm frame is modeled with an arm length of 0.25 m. Mass moments of inertia are estimated as Ixx=Iyy=0.035 and Izz=0.065 kg m². The thrust coefficient (1.4e-5 N/(rad/s)²), propeller torque coefficient (2.5e-7 N m/(rad/s)²), rotor inertia (1e-5 kg m²), allowed torque (0.26 N m), loaded rotor speed cap (850 rad/s), motor dynamics, and power coefficient are placeholders, **not guaranteed by motor KV or prop diameter**. The motor no-load speed is about 13,616 rpm at 14.8 V, not the same as usable loaded speed.

To validate the prototype choice, obtain part datasheets or thrust-stand results for the *specific* motor/propeller/ESC pairing, a CAD or mass-derived inertia matrix, and maximum current/power data for all four motors and the battery's C rating. Replace the assumptions in the `Parameters` dataclass and rerun tests. Calibrate the rotor power coefficient to measured electrical power if available.

## Implementation notes

`drone_simulation.py` implements a six-DOF nonlinear quadrotor model and four torque-driven rotor states. It produces hover, circular, and two-leg mission trajectories, figures, CSV logs, and summary statistics. `test_simulation.py` performs self-chosen numerical regression checks. See `REPORT_SECTION.md` for equations and preliminary results. The circle case is initialized in flight at 1 m with the intended tangential velocity. The code does not simulate actual Pixhawk firmware, optical-flow sensing, or ground contact.

**Course compliance:** put the code into the team GitHub repository, include its link in the report, and follow the syllabus AI/SI policy.
