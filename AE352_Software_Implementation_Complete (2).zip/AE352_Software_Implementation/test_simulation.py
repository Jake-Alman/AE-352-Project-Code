"""Automated regression checks for the AE352 quadrotor simulation.

These are self-defined numerical tolerances, NOT instructor-defined pass criteria.
"""
import numpy as np
from drone_simulation import simulate, stats, P


def test_scenario(name):
    sim = simulate(name, dt=0.2)
    metrics = stats(name, sim)
    assert metrics['total_energy_Wh'] < P.battery_Wh * P.usable_fraction
    assert metrics['max_motor_speed_rad_s'] <= P.max_rotor_speed + 1e-4
    assert metrics['max_motor_torque_Nm'] <= P.max_motor_torque + 1e-6
    if name == 'hover':
        assert abs(metrics['hover_mean_altitude_m'] - 1.) < 0.05
        assert metrics['hover_max_altitude_error_m'] < 0.05
    elif name == 'circle':
        assert abs(metrics['circle_mean_radius_m'] - 2.) < 0.10
        assert abs(metrics['circle_mean_speed_m_s'] - 0.5) < 0.05
        assert abs(metrics['circle_mean_altitude_m'] - 1.) < 0.05
    elif name == 'mission':
        assert metrics['first_leg_endpoint_error_m'] < 0.10
        assert metrics['second_leg_endpoint_error_m'] < 0.10
        assert abs(metrics['final_yaw_deg'] - 90) < 1.
        assert abs(metrics['final_altitude_m']) < 0.01
        assert abs(metrics['final_vertical_speed_m_s']) <= 0.01
        t, s = sim['t'], sim['s']
        for start, end, axis in ((7.,12.,0),(20.,25.,1)):
            i0, i1 = np.argmin(abs(t-start)), np.argmin(abs(t-end))
            avg_speed = (s[i1,axis]-s[i0,axis])/(end-start)
            assert 0.9 <= avg_speed <= 1.1
    print(f'PASS: {name}: {metrics}')


if __name__ == '__main__':
    for name in ('hover','circle','mission'):
        test_scenario(name)
    print('All simulated performance checks passed (illustrative parameters).')
