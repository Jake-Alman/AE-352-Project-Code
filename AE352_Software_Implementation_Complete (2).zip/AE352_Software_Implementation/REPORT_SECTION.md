# Software and Implementation of the Quadrotor Digital Twin

## Software architecture and physical configuration

The quadrotor digital twin was implemented in Python using NumPy, SciPy (`solve_ivp` with adaptive RK45), and Matplotlib. The simulation separates trajectory generation, position and attitude controllers, rotor allocation, motor dynamics, rigid-body equations of motion, and performance evaluation. Its model incorporates the team's proposed off-the-shelf component classes: a 500 mm carbon-fiber frame, four 920 KV brushless motors and 10-inch propellers, a 4S 5000 mAh LiPo battery, a Pixhawk flight controller, and an optical-flow sensor. The estimated assembled mass is 1.7 kg; 0.3 kg of ballast is added for a modeled total mass of **2.0 kg**. The Pixhawk and optical-flow sensor are included in the hardware concept, but the simulation uses ideal state feedback: firmware and optical-flow measurement errors have **not** been simulated.

The specified 500 mm frame is **assumed** to describe the distance between opposite motor centers; thus each motor is placed 0.25 m from the center of mass. The frame's manufacturer and dimensional convention must be checked. The 920 KV constant and nominal 4S voltage imply an ideal no-load angular speed of approximately 13,616 rpm, but neither KV nor propeller diameter alone determines real loaded thrust, motor torque or power. Accordingly, the numerical thrust and torque coefficients, allowable motor torque, loaded speed limit, rotor inertia, and energy/power mapping remain **model assumptions**, not measured characteristics of the chosen parts.

## Equations and implementation

The six-degree-of-freedom rigid-body model includes center-of-mass position **r**, velocity **v**, attitude quaternion **q**, and body angular velocity **ω**. Four additional rotor speeds Ω₁ through Ω₄ and accumulated energy E are integrated. Euler angles are extracted for plotting, not integrated as the attitude state. With inertial +z upward, the model uses

- **ṙ = v**
- **m v̇ = R(q) [0, 0, Σ k_f Ωᵢ²]ᵀ − mg e_z**
- **I ω̇ + ω × (Iω) = M**
- **J_r Ω̇ᵢ = τᵢ − k_q Ωᵢ²**
- **q̇ = ½ q ⊗ [0, ω]** (scalar-first quaternion convention)

Here, m = 2.0 kg; R(q) is the body-to-inertial rotation; g = 9.81 m/s²; I is the estimated rigid-body inertia tensor; k_f is the rotor thrust coefficient; k_q is the propeller reaction-torque coefficient; J_r is rotor rotational inertia; τᵢ is applied motor torque; and Ωᵢ is rotor speed. The rotors are ordered at +x, +y, −x and −y. Assuming alternating spin directions **s = (+1, −1, +1, −1)**, the body moments are

**Mₓ = L(T₂ − T₄), Mᵧ = L(T₃ − T₁), M_z = −Σsᵢτᵢ**, with **Tᵢ = k_fΩᵢ²** and **L = 0.25 m**. This yaw expression uses the instantaneous motor reaction torque (including contributions due to accelerating rotors). Airframe aerodynamic drag, gusts, ground effects, gyro coupling, sensor noise, and contact dynamics are omitted. The assignment permits neglecting drag.

A smooth reference trajectory specifies desired position, velocity, acceleration, yaw, and yaw rate. A PD position controller calculates required force **F_d = m[a_d + K_p(r_d − r) + K_d(v_d − v) + ge_z]**. Desired attitude aligns the drone's body vertical axis with F_d and its heading with the requested yaw. A second PD controller requests moments, and a 4×4 mixer converts collective thrust and moments to desired squared rotor speeds. Rotor-speed commands and motor torques are saturated to model actuator limits. Actual thrust and body moments are calculated from the integrated motor states, not directly from the reference trajectory. Motor torque is therefore the only commanded physical actuator in the model.

The assumed inertia values are **Ixx = Iyy = 0.035 kg·m², Izz = 0.065 kg·m²**; aerodynamic coefficients are **k_f = 1.4×10⁻⁵ N/(rad/s)²** and **k_q = 2.5×10⁻⁷ N·m/(rad/s)²**. Other assumed actuator parameters are **J_r = 1.0×10⁻⁵ kg·m², maximum loaded speed = 850 rad/s, maximum absolute motor torque = 0.26 N·m**, and a **0.055 s** rotor-speed control time constant. These values require part-specific confirmation before claims about real hardware performance can be made.

## Simulation scenarios and results

The three flight programs correspond to the assignment: (1) ascend to 1 m and hover there for 120 s; (2) fly a 2 m radius circle at nominal 0.5 m/s and 1 m altitude for 60 s; and (3) launch, fly two 5 m legs with a 90° left yaw in between, then land vertically. The circle simulation begins from an idealized state already in flight at 1 m and at the designated tangential speed. The final mission uses a 120 s minimum-jerk descent so the terminal vertical speed is below 0.01 m/s. Ground contact is represented only by reaching z≈0, not by impact/contact physics.

| Scenario | Result with 2.0 kg model |
|---|---|
| Hover | Mean altitude **1.0000 m** over 120 s; maximum altitude error **0.0019 m**; total energy **5.462 Wh** including takeoff |
| Circle | Mean radius **2.0057 m**; mean speed **0.5017 m/s**; mean altitude **1.000 m**; maximum radius error **0.0350 m** over the assessed 60 s; total energy **2.841 Wh** over 65 s |
| Two-leg mission | First endpoint error **0.0100 m**; second endpoint error **0.0103 m**; final yaw **90.0°**; final altitude ≈ **0 m**; final vertical speed ≈ **0 m/s**; total energy **6.648 Wh** over 152 s |

The mission's maximum instantaneous position tracking error is approximately **0.440 m** during rapid transitions, even though final waypoint errors are much smaller. This limitation should be disclosed: passing the selected numerical tolerances does not establish perfect tracking at every instant.

## Battery, testing, limitations, and reproducibility

For a **4S 5000 mAh LiPo**, using nominal **14.8 V**, the nominal stored energy is **14.8 V × 5 Ah = 74 Wh**. Assuming **80% usable capacity** yields **59.2 Wh**. The current model estimates energy use through a coefficient multiplying ΣΩᵢ³ plus an 8 W electronics load. This **power model is not verified against motor/propeller measurements**, so energy feasibility is preliminary rather than proof of real battery endurance. In particular, current draw, ESC limits, battery voltage sag, and discharge rating have not yet been checked.

The test script runs each scenario, checks energy usage and actuator limits, and compares performance metrics with project-team regression tolerances; these are **not supplied by the instructor**. The resulting position, Euler angle, motor speed/torque, and overhead trajectory graphs are exported under `figures/`. Time histories are exported as CSV; summary metrics are stored in `simulation_results.json`. Execute `python drone_simulation.py` to generate results, then `python test_simulation.py` to reproduce the checks. The code and documentation should be placed on the team's GitHub repository and linked in the submission, as specified by reporting requirement RR5. AI/SI usage must follow the course syllabus.

### Suggested contribution statement

**Software and Implementation Lead:** Implemented the team's 2.0 kg quadrotor digital twin in Python, including 6-DOF rigid-body equations, motor torque and rotor-speed dynamics, a trajectory-following controller, numerical integration, all three required flight simulations, performance tests, battery-energy estimates, and generated trajectory and actuator plots.
